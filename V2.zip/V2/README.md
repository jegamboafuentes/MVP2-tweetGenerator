# Metaverse_Browser_extension_template
 Metaverse Browser extension template, with ExtPay integrated
  